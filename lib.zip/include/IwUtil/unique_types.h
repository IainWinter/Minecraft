#pragma once

namespace iwutil {
	template <typename... Trest>
	struct unique_types;

	template <typename T1, typename T2, typename... Trest>
	struct unique_types<T1, T2, Trest...>
		: unique_types<T1, T2>, 
		  unique_types<T1, Trest...>, 
		  unique_types<T2, Trest...> 
	{};

	template <class T1, class T2>
	struct unique_types<T1, T2> {
		static_assert(!std::is_same<T1, T2>::value, "Types must be unique");
	};
}