#pragma once

#include <iterator>
#include <vector>
#include "sparse_set.h"
#include "input_iterator_ptr.h"

namespace iwutil {
	template<typename T>
	class sparse_array {
	private:
		T* m_data;
		sparse_set m_index;
	public:
		using iterator = typename input_iterator_ptr<T>;

		sparse_array(unsigned int count)
			: m_index(count, count)
		{
			m_data = new T[count];
		}

		~sparse_array() {
			delete m_data;
		}

		bool insert(unsigned int index, const T& data) {
			m_index.insert(index);
			int data_index = m_index.at(index);
			bool data_has_index = data_index != -1;
			if (data_has_index) {
				m_data[data_index] = data;
			}

			return data_has_index;
		}

		bool remove(unsigned int index) {
			unsigned int data_count = m_index.count();
			int data_index = m_index.at(index);
			bool data_has_index = data_index != -1;
			if (data_has_index) {
				m_data[data_index] = m_data[data_count - 1];
				m_index.remove(index);
			}

			return data_has_index;
		}

		T* at(unsigned int index) {
			int data_index = m_index.at(index);
			bool data_has_index = data_index != -1;
			if (data_has_index) {
				return &m_data[data_index];
			}

			return nullptr;
		}

		void clear() {
			m_index.clear();
		}

		unsigned int count() {
			return m_index.count();
		}

		iterator begin() {
			return iterator(m_data);
		}

		iterator end() {
			return iterator(m_data + m_index.count() - 1);
		}
	};
}