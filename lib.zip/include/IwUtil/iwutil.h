#pragma once

#ifdef IWUTIL_EXPORTS
#	define IWUTIL_API __declspec(dllexport)
#else
#	define IWUTIL_API __declspec(dllimport)
#endif