#pragma once

namespace iwutil {
	template <typename... T>
	struct unique_types;

	template<typename T>
	struct unique_types<T> {};

	template <typename T1, typename T2, typename... T>
	struct unique_types<T1, T2, T...>
		: unique_types<T1, T2>, 
		  unique_types<T1, T...>, 
		  unique_types<T2, T...> 
	{};

	template <class T1, class T2>
	struct unique_types<T1, T2> {
		static_assert(!std::is_same<T1, T2>::value, "Types must be unique");
	};
}