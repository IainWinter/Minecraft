#pragma once

#include <cstddef>
#include "iwutil.h"

namespace iwutil {
	using id_t = std::size_t;

	/**
	* Static type to store a type id. Can be used at runtime to replace typeid(T).hash_code().
	* @tparam T Type to id.
	*/
	template<typename T>
	class type_identifier {
	private:
		static id_t m_id;
	public:
		/**
		* Returns the id of T.
		* @return The id of T.
		*/
		static const id_t get_id() {
			return m_id;
		}

		/**
		* Returns K's sub id in T.
		* @tparam K Type to id.
		* @return The sub id of K in T.
		*
		*/
		template<typename K>
		static const id_t get_id() {
			static const id_t type_id = m_id++;
			return type_id;
		}
	};

	template <typename T>
	id_t type_identifier<T>::m_id = 0;

	/**
	* Provides functions for getting type ids.
	* Useful in templated classes where distinguishing between different types is needed.
	* @tparam T Generally the class being inherited to.
	*/
	template<typename T>
	class identify_by {
	public:
		/**
		* Returns the id of T.
		* @return T's id
		*/
		id_t get_id() {
			return type_identifier<T>::get_id();
		}

		/**
		* Returns K's sub id in T.
		* @tparam K The type to id.
		* @return The sub id of K in T.
		*/
		template<typename K>
		id_t get_type_id() {
			return type_identifier<T>::template get_id<K>();
		}
	};
}