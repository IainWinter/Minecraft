#pragma once

#include <iterator>

namespace iwutil {
	template<typename T>
	class input_iterator_ptr {
	private:
		T* m_ptr;
	public:
		using iterator_category = std::input_iterator_tag;
		using value_type		= std::remove_cv_t<T>;
		using difference_type	= std::ptrdiff_t;
		using pointer			= T*;
		using reference			= T&;

		input_iterator_ptr(T* ptr)
			: m_ptr(ptr) {}

		input_iterator_ptr(const input_iterator_ptr& itr)
			: m_ptr(itr.m_ptr) {}

		input_iterator_ptr& operator=(const input_iterator_ptr& itr) {
			m_ptr = itr.m_ptr;
			return *this;
		}

		input_iterator_ptr& operator++() {
			++m_ptr;
			return *this;
		}

		input_iterator_ptr operator++(int) {
			input_iterator_ptr tmp(*this);
			++*this;
			return tmp;
		}

		bool operator==(const input_iterator_ptr& itr) {
			return m_ptr == itr.m_ptr;
		}

		bool operator!=(const input_iterator_ptr& itr) {
			return m_ptr != itr.m_ptr;
		}

		T& operator*() {
			return *m_ptr;
		}

		T* operator->() {
			return &m_ptr;
		}
	};
}