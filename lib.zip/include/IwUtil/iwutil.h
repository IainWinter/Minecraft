#pragma once

#ifdef IWUTIL_EXPORTS
#	define IWUTIL_API __declspec(dllexport)
#else
#	define IWUTIL_API __declspec(dllimport)
#endif

#include <tuple>

namespace iwutil {
	class private_impl {
	private:
		template<class StructT, class TupleT, std::size_t... IndexT>
		static StructT make_struct(TupleT&& tuple, std::index_sequence<IndexT...>) {
			return { std::get<IndexT>(std::forward<TupleT>(tuple))... };
		}

		template<class StructT, class TupleT, std::size_t... IndexT>
		static StructT make_struct(const TupleT& tuple, std::index_sequence<IndexT...>) {
			return { std::get<IndexT>(tuple)... };
		}
	public:
		template<class StructT, class TupleT>
		static StructT make_struct(TupleT&& tuple) {
			constexpr static std::size_t size = std::tuple_size<std::decay_t<TupleT>>::value;
			return make_struct<StructT>(
				std::forward<TupleT>(tuple),
				std::make_index_sequence<size>()
			);
		}

		template<class StructT, class TupleT>
		static StructT make_struct(const TupleT& tuple) {
			constexpr static std::size_t size = std::tuple_size<std::decay_t<TupleT>>::value;
			return make_struct<StructT>(
				tuple,
				std::make_index_sequence<size>()
			);
		}
	};

	template<class StructT, class TupleT>
	StructT make_struct(TupleT&& tuple) {
		return private_impl::make_struct<StructT, TupleT>(std::move(tuple));
	}

	template<class StructT, class TupleT>
	StructT make_struct(const TupleT& tuple) {
		return private_impl::make_struct<StructT, TupleT>(tuple);
	}
}