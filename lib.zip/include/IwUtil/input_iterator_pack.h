#pragma once

#include "dynamic_tuple.h"
#include "input_iterator_ptr.h"
#include <vector>

namespace iwutil {
	template<typename... T>
	class input_iterator_pack {
	public:
		using iterator_type_tuple = dynamic_tuple<typename T::reference...>;
	private:
		using iterator_tuple = dynamic_tuple<T...>;
		iterator_tuple m_itrs;
	public:
		input_iterator_pack(T&&... args)
			: m_itrs(std::forward<T>(args)...) {}

		input_iterator_pack(const input_iterator_pack& copy)
			: m_itrs(copy.m_itrs) {}

		input_iterator_pack(input_iterator_pack&& copy)
			: m_itrs(copy.m_itrs) {}

		input_iterator_pack operator++() {
			m_itrs.foreach(functors::increment());
			return *this;
		}

		input_iterator_pack operator++(int) {
			input_iterator_pack tmp(*this);
			++*this;
			return tmp;
		}

		bool operator==(const input_iterator_pack& itr) const {
			return m_itrs == itr.m_itrs;
		}

		bool operator!=(const input_iterator_pack& itr) const {
			return m_itrs != itr.m_itrs;
		}

		iterator_type_tuple operator*() {
			iterator_type_tuple itt = iterator_type_tuple(*m_itrs.get<T>()...);
			return itt;
		}
	};
}