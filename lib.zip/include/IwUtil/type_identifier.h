#pragma once

#include "iwutil.h"

namespace iwutil {
	using id_t = unsigned long long;

	template<typename T>
	class type_identifier {
	private:
		static id_t m_next_id;
	public:
		template<typename T>
		static const id_t get_id() {
			static const id_t type_id = m_next_id++;
			return type_id;
		}

		static const id_t get_id() {
			return m_next_id;
		}
	};

	template <typename T>
	id_t type_identifier<T>::m_next_id = 0;
}