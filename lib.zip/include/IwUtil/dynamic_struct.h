#pragma once

#include <tuple>
#include <unordered_map>
#include <array>
#include "type_identifier.h"
#include "unique_types.h"

namespace iwutil {
	using byte = char;

	/**
	* Can be used like a tuple, but can be index on type at runtime. Types must be unique.
	* @tparam T... The types to store.
	*/
	template<typename... T>
	class dynamic_struct : unique_types<T...> {
	private:
		byte* m_data;
		std::unordered_map<id_t, std::size_t> m_locations;

		template<typename K>
		K* get_ptr() {
			id_t id = type_identifier<dynamic_struct<T...>>::get_id<K>();
			std::size_t location = m_locations[id];
			K* ptr = (K*)(m_data + location);
			return ptr;
		}
	public:
		dynamic_struct() {
			constexpr std::size_t count = sizeof...(T);
			std::size_t ids[count]	 = { type_identifier<dynamic_struct<T...>>::get_id<T>()... };
			std::size_t sizes[count] = { sizeof(T)... };

			std::size_t total_size = 0;
			for (int i = 0; i < count; i++) {
				id_t id = ids[i];
				m_locations[id] = total_size;
				total_size += sizes[i];
			}

			m_data = (byte*)malloc(total_size);
		}

		dynamic_struct(T&&... args) {
			constexpr std::size_t count  = sizeof...(T);
			std::size_t ids		 [count] = { type_identifier<dynamic_struct<T...>>::get_id<T>()... };
			std::size_t sizes    [count] = { sizeof(T)... };
			void*		data_ptrs[count] = { &args... };

			std::size_t total_size = 0;
			for (int i = 0; i < count; i++) {
				id_t id = ids[i];
				m_locations[id] = total_size;
				total_size += sizes[i];
			}

			m_data = (byte*)malloc(total_size);
			for (int i = 0; i < count; i++) {
				byte* ptr = m_data + m_locations[i];
				void* data_ptr = data_ptrs[i];
				std::size_t data_size = sizes[i];
				memcpy(ptr, data_ptr, data_size);
			}
		}

		~dynamic_struct() {
			delete[] m_data;
		}

		/**
		* Gets the data of the specified type.
		* @tparam K The type to get.
		* @return The data of K.
		*/
		template<typename K>
		K& get() {
			K* ptr = get_ptr<K>();
			return *ptr;
		}

		/**
		* Sets the data of the specified type.
		* @tparam K The type to get.
		*/
		template<typename K>
		void set(const K& data) {
			K* ptr = get_ptr<K>();
			*ptr = data;
		}
	};
}