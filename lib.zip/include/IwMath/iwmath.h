#pragma once

#ifdef IWMATH_EXPORTS
#define IWMATH_API __declspec(dllexport)
#else
#define IWMATH_API __declspec(dllimport)
#endif

/** 
* Pi ~ 3.14 
*/
#define IW_PI 3.14159265359f

/**
* e ~ 2.71
*/
#define IW_E 2.71828182846f

/**
* Phi ~ 1.62
*/
#define IW_PHI 1.61803398875f

namespace iwmath {
	/**
	* Returns the inverse square root of the specified value.
	*
	* @param value Value to inverse square root.
	*/
	float inv_sqrt(float value);
}