#pragma once

#include "iwutil.h"

namespace iwutil {
	class IWUTIL_API sparse_set {
	private:
		unsigned int* m_dense;
		unsigned int* m_sparse;
		unsigned int  m_count;
		unsigned int  m_dense_capacity;
		unsigned int  m_sparse_capacity;
	public:
		sparse_set(unsigned int dence_capacity, unsigned int sparse_capacity);
		~sparse_set();

		bool insert(unsigned int index);
		bool remove(unsigned int index);
		int at(unsigned int index);

		void clear() {
			m_count = 0;
		}

		unsigned int count() {
			return m_count;
		}

		unsigned int sparse_capacity() {
			return m_sparse_capacity;
		}

		unsigned int dense_capacity() {
			return m_dense_capacity;
		}
	};
}