#pragma once

#include <cstddef>
#include "iwutil.h"

namespace iwutil {
	using id_t = std::size_t;

	/**
	* Static type to store a type id. Can be used at runtime to replace typeid(T).hash_code().
	* @tparam T Type to id.
	*/
	template<typename T>
	class type_identifier {
	private:
		static id_t m_id;
	public:
		/**
		* Returns the id of the type.
		* @return The id of the type.
		*/
		static const id_t get_id() {
			return m_id;
		}

		/**
		* Returns the type id in the context of another type.
		* @tparam K Type to id.
		* @return The id of K in the context of T.
		*
		*/
		template<typename K>
		static const id_t get_id() {
			static const id_t type_id = m_id++;
			return type_id;
		}
	};

	template <typename T>
	id_t type_identifier<T>::m_id = 0;
}